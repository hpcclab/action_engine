def lambda_handler(event, context):
    user_id = event.get("user_id", "unknown_id")
    user_name = event.get("name", "unknown")

    mood = "happy" if "anna" in user_name.lower() else "neutral"

    return {
        "mood": mood,
        "name": user_name  # Pass through
    }
