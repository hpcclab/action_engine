def lambda_handler(event, context):
    mood = event.get("mood", "neutral")
    
    if mood == "happy":
        song = "Happy Tune"
    elif mood == "sad":
        song = "Melancholy Melody"
    else:
        song = "Lo-fi Chill"

    return {
        "recommended_song": song
    }
