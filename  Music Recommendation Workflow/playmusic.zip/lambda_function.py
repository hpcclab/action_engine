def lambda_handler(event, context):
    song_title = event.get("recommended_song", "unknown song")
    name = event.get("name", "someone")

    return {
        "message": f"Now playing: {song_title}",
        "name": name
    }