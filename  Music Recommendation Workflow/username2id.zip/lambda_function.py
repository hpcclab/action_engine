def lambda_handler(event, context):
    user_name = event.get("user_name", "unknown")
    user_id = f"{user_name.lower()}_123"
    return {
        "user_id": user_id,
        "name": user_name  # Pass through
    }
