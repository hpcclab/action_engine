import boto3
import os
import json
import uuid
import base64 

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    """
    1. Gets an image from S3 by intelligently handling input from the Action Engine or direct tests.
    2. Packages it into a JSON with metadata.
    3. Saves this JSON to a temporary key in S3 (the "claim check").
    4. Returns the temporary S3 key to keep the payload small.
    """
    
    bucket_name = None
    original_s3_key = None

    # Handle input from Action Engine UI ('input_files') or direct invocation ('s3_key')
    if 'input_files' in event and isinstance(event['input_files'], list) and event['input_files']:
        s3_uri = event['input_files'][0]  # Take the first file from the list
        # s3_uri is expected in the format 's3://bucket-name/key'
        if s3_uri.startswith("s3://"):
            uri_parts = s3_uri.replace("s3://", "").split('/', 1)
            if len(uri_parts) == 2:
                bucket_name, original_s3_key = uri_parts
    elif 's3_key' in event:
        # Fallback for direct testing
        original_s3_key = event.get('s3_key')
        bucket_name = event.get('bucket_name', 'automatic-workflow-files')  # Default bucket if not provided

    # Validate that we have the necessary details
    if not original_s3_key or not bucket_name:
        return {
            "success": False, 
            "error": "Input is invalid. It must include 'input_files' (as s3://bucket/key) or both 's3_key' and 'bucket_name'."
        }

    try:
        # Step 1: Get the original image
        response = s3_client.get_object(Bucket=bucket_name, Key=original_s3_key)
        image_data = response['Body'].read()
        
        # Step 2: Create the data package (this would be too large to return directly)
        data_package = {
            "image_data_b64": base64.b64encode(image_data).decode('utf-8'),
            "content_type": response.get('ContentType', 'image/jpeg'),
            "original_s3_key": original_s3_key,
            "bucket_name": bucket_name
        }
        
        # Step 3: Save this package to a new temporary key in S3
        temp_key = f"temp/{uuid.uuid4().hex}.json"
        s3_client.put_object(
            Bucket=bucket_name,
            Key=temp_key,
            Body=json.dumps(data_package),
            ContentType='application/json'
        )
        
        # Step 4: Return the "claim check" (the reference to the temp file)
        return {
            "success": True,
            "claim_check_s3_key": temp_key,
            "bucket_name": bucket_name
        }

    except Exception as e:
        return {"success": False, "error": str(e)}
