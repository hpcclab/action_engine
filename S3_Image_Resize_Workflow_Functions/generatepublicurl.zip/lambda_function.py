import boto3
import os

def lambda_handler(event, context):
    """
    Receives the final S3 key from the previous step and generates a 
    public URL for it.
    """
    # Look for 'final_s3_key' from the event payload.
    final_s3_key = event.get('final_s3_key')
    
    if not final_s3_key:
        # This error message is more specific to help with future debugging.
        return {"success": False, "error": "Input did not include 'final_s3_key'."}
        
    bucket_name = event.get('bucket_name')
    region = os.environ.get('AWS_REGION', 'us-east-2')
    
    try:
        # Construct the public URL
        public_url = f"https://{bucket_name}.s3.{region}.amazonaws.com/{final_s3_key}"
        
        # This is the final output of the entire workflow
        return {
            "success": True,
            "public_url": public_url,
            "s3_key": final_s3_key
        }
        
    except Exception as e:
        return {"success": False, "error": str(e)}