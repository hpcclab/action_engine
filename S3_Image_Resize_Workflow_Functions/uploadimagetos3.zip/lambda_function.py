import boto3
import base64
import os

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    """
    1. Receives the Base64-encoded RESIZED image data.
    2. Decodes it and uploads it to a final destination in S3.
    3. Returns the final S3 key.
    """
    # This is the Base64 data from the 'resizeimage' function
    resized_b64 = event.get('resized_image_data_b64') # <--- We expect this key
    
    # Get the other necessary info from the event payload
    bucket_name = event.get('bucket_name')
    original_s3_key = event.get('original_s3_key')

    if not resized_b64 or not bucket_name or not original_s3_key:
        # Construct a detailed error message for easier debugging
        missing = []
        if not resized_b64: missing.append("'resized_image_data_b64'")
        if not bucket_name: missing.append("'bucket_name'")
        if not original_s3_key: missing.append("'original_s3_key'")
        return {"success": False, "error": f"Input missing required keys: {', '.join(missing)}."}
        
    try:
        image_bytes = base64.b64decode(resized_b64)
        
        # Create the new, final key for the resized image
        base, ext = os.path.splitext(original_s3_key)
        final_s3_key = f"resized/{os.path.basename(base)}_256x256{ext or '.jpg'}"
        
        s3_client.put_object(
            Bucket=bucket_name,
            Key=final_s3_key,
            Body=image_bytes,
            ContentType=event.get('content_type', 'image/jpeg')
        )
        
        # Pass the final key to the next function
        return {
            "success": True,
            "final_s3_key": final_s3_key, 
            "bucket_name": bucket_name
        }
        
    except Exception as e:
        return {"success": False, "error": str(e)}