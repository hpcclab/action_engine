import boto3
import json
import base64
from PIL import Image
import io

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    """
    1. Receives a "claim check" (an S3 key to a JSON file).
    2. Downloads and reads the JSON file to get the image data.
    3. Resizes the image.
    4. Returns the RESIZED image data as a Base64 string.
    """
    claim_check_s3_key = event.get('claim_check_s3_key')
    bucket_name = event.get('bucket_name')

    if not claim_check_s3_key or not bucket_name:
        return {"success": False, "error": "Input missing 'claim_check_s3_key' or 'bucket_name'."}

    try:
        # Step 1: Use the claim check to get the data package from S3
        response = s3_client.get_object(Bucket=bucket_name, Key=claim_check_s3_key)
        data_package = json.loads(response['Body'].read())
        
        image_bytes = base64.b64decode(data_package['image_data_b64'])
        image = Image.open(io.BytesIO(image_bytes))

        # Step 2: Resize the image
        target_width, target_height = 256, 256
        new_image = Image.new('RGB', (target_width, target_height), 'white')
        image.thumbnail((target_width, target_height), Image.Resampling.LANCZOS)
        new_image.paste(image, ((target_width - image.width) // 2, (target_height - image.height) // 2))

        # Step 3: Save resized image to a buffer and encode to Base64
        output_buffer = io.BytesIO()
        new_image.save(output_buffer, format='JPEG', quality=95)
        resized_b64 = base64.b64encode(output_buffer.getvalue()).decode('utf-8')

        # Clean up the temporary file from S3
        s3_client.delete_object(Bucket=bucket_name, Key=claim_check_s3_key)

        # Step 4: Return the resized data, which should be small enough
        return {
            "success": True,
            "resized_image_data_b64": resized_b64,
            "content_type": "image/jpeg",
            "bucket_name": bucket_name,
            "original_s3_key": data_package['original_s3_key']
        }

    except Exception as e:
        return {"success": False, "error": str(e)}